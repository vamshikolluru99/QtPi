Make sure django and python 3.8+ are installed in ur virtual env
Next Make sure everything in requires.txt is installed using the command pip isntall -r requires.txt
Next use python manage.py runserver
