from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer


bot = ChatBot('vamshi')

training = ChatterBotCorpusTrainer(bot)

training.train(
    'chatterbot.corpus.english',
)


#print(bot.get_response('Hii Good Morning'))

print('\n Lets chat with me')

d = True
while d:
    inp = input('you:')

    if inp == 'done':
        d = False
        print('\n Thank you')


    else:
        response = bot.get_response(inp)
        print('bot:',response)
