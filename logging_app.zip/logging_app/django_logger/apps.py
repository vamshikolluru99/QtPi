

from django.apps import AppConfig


class loggerConfig(AppConfig):
    name = 'django_logger'
