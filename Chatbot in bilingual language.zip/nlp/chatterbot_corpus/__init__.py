"""
A machine readable multilingual dialog corpus.
"""

__version__ = '1.2.0'
__author__ = 'Vamshi kolluru'
__email__ = 'vamshi.kolluru99@gmail.com'
__url__ = 'https://github.com/kolluruvamshi/chatterbot-corpus'
